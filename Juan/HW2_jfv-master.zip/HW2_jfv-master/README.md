# HW2_jfv

### Projection and perturbation methods

Matlab code to solve homework 2 for Econ 714 - Computational Economics @ UPenn 

Fall 2019
